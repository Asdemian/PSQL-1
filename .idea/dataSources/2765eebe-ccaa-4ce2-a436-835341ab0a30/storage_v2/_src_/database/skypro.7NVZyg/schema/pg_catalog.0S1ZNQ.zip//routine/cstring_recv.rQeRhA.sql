create function cstring_recv(internal) returns cstring
    language internal
as
$$cstring_recv$$;

comment on function cstring_recv(internal) is 'I/O';

