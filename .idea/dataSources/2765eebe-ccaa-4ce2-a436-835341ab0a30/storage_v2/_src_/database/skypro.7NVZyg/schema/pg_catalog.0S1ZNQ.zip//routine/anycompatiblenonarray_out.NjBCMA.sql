create function anycompatiblenonarray_out(anycompatiblenonarray) returns cstring
    language internal
as
$$anycompatiblenonarray_out$$;

comment on function anycompatiblenonarray_out(anycompatiblenonarray) is 'I/O';

