create function boolle(boolean, boolean) returns boolean
    language internal
as
$$boolle$$;

comment on function boolle(bool, bool) is 'implementation of <= operator';

