create function brinhandler(internal) returns index_am_handler
    language internal
as
$$brinhandler$$;

comment on function brinhandler(internal) is 'brin index access method handler';

