create function bytea_string_agg_transfn(internal, bytea, bytea) returns internal
    language internal
as
$$bytea_string_agg_transfn$$;

comment on function bytea_string_agg_transfn(internal, bytea, bytea) is 'aggregate transition function';

