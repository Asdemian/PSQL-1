create function "RI_FKey_setnull_upd"() returns trigger
    language internal
as
$$RI_FKey_setnull_upd$$;

comment on function "RI_FKey_setnull_upd"() is 'referential integrity ON UPDATE SET NULL';

