create function btint42cmp(integer, smallint) returns integer
    language internal
as
$$btint42cmp$$;

comment on function btint42cmp(int4, int2) is 'less-equal-greater';

