create function bit_count(bytea) returns bigint
    language internal
as
$$bytea_bit_count$$;

comment on function bit_count(bit) is 'number of set bits';

