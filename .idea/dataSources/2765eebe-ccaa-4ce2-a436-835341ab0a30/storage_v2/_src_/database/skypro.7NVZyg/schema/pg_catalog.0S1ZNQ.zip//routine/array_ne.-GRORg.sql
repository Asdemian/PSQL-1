create function array_ne(anyarray, anyarray) returns boolean
    language internal
as
$$array_ne$$;

comment on function array_ne(anyarray, anyarray) is 'implementation of <> operator';

