create function col_description(oid, integer) returns text
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function col_description(oid, int4) is 'get description for table column';

