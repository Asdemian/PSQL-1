create function anyarray_send(anyarray) returns bytea
    language internal
as
$$anyarray_send$$;

comment on function anyarray_send(anyarray) is 'I/O';

