create function brin_minmax_multi_distance_time(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_time$$;

comment on function brin_minmax_multi_distance_time(internal, internal) is 'BRIN multi minmax time distance';

