create function bpcharregexne(character, text) returns boolean
    language internal
as
$$textregexne$$;

comment on function bpcharregexne(bpchar, text) is 'implementation of !~ operator';

