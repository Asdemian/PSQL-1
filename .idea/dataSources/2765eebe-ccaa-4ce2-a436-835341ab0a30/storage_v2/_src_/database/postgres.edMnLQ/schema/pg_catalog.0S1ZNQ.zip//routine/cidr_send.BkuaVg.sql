create function cidr_send(cidr) returns bytea
    language internal
as
$$cidr_send$$;

comment on function cidr_send(cidr) is 'I/O';

