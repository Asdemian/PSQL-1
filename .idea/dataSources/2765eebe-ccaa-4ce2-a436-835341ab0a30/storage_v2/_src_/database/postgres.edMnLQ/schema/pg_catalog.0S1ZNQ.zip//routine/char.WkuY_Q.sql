create function char(integer) returns "char"
    language internal
as
$$i4tochar$$;

comment on function char(int4) is 'convert int4 to char';

