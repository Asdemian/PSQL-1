create function byteain(cstring) returns bytea
    language internal
as
$$byteain$$;

comment on function byteain(cstring) is 'I/O';

