create function btboolcmp(boolean, boolean) returns integer
    language internal
as
$$btboolcmp$$;

comment on function btboolcmp(bool, bool) is 'less-equal-greater';

