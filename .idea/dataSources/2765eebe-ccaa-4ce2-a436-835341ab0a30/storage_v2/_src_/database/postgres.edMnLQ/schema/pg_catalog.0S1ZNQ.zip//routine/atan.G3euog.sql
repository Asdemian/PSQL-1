create function atan(double precision) returns double precision
    language internal
as
$$datan$$;

comment on function atan(float8) is 'arctangent';

