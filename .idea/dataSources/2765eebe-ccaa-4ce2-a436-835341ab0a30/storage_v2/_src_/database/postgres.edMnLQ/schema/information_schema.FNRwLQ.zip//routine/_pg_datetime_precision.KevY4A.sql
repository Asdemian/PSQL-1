create function _pg_datetime_precision(typid oid, typmod integer) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

