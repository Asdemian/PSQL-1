create function box(point, point) returns box
    language internal
as
$$points_box$$;

comment on function box(polygon) is 'convert polygon to bounding box';

