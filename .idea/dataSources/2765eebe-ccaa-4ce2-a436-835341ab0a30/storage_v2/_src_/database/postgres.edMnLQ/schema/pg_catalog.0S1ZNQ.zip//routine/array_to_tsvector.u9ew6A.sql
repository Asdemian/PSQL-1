create function array_to_tsvector(text[]) returns tsvector
    language internal
as
$$array_to_tsvector$$;

comment on function array_to_tsvector(_text) is 'build tsvector from array of lexemes';

